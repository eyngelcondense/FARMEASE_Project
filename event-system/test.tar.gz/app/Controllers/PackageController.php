<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class PackageController extends BaseController
{
    public function index()
    {
        //
    }
}
